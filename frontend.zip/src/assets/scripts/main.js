function move(){
    $("#bod").css("left", "20");
}