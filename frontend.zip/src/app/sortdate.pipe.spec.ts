import { SortdatePipe } from './sortdate.pipe';

describe('SortdatePipe', () => {
  it('create an instance', () => {
    const pipe = new SortdatePipe();
    expect(pipe).toBeTruthy();
  });
});
